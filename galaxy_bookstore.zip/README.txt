Galaxy BookStore — Static Website
Files:
- index.html
- styles.css
- script.js

How to use:
1. Unzip the archive.
2. Upload the folder to GitHub repository and enable GitHub Pages (use main branch / root).
3. Alternatively, open index.html locally.

This site is a single-page, responsive static HTML/CSS/JS demo with:
- Space/galaxy aesthetic (white + sky blue)
- Animated hero planets
- Slider (autoplay) with featured books
- Add-to-cart, cart sidebar and checkout modal (simulated)
- SVG "stickers" and placeholders so no external images required
