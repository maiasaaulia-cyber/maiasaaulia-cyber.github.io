// script.js — interactive behavior for Galaxy BookStore
document.addEventListener('DOMContentLoaded', () => {
  // year
  document.getElementById('year').textContent = new Date().getFullYear();

  // simple cart state
  const cart = {};
  const cartCountEl = document.getElementById('cartCount');
  const cartItemsEl = document.getElementById('cartItems');
  const cartTotalEl = document.getElementById('cartTotal');
  const openCartBtn = document.getElementById('openCart');
  const cartSidebar = document.getElementById('cartSidebar');
  const closeCartBtn = document.getElementById('closeCart');
  const clearCartBtn = document.getElementById('clearCart');
  const checkoutBtn = document.getElementById('checkoutBtn');
  const checkoutModal = document.getElementById('checkoutModal');
  const closeCheckout = document.getElementById('closeCheckout');
  const checkoutForm = document.getElementById('checkoutForm');
  const checkoutSummary = document.getElementById('checkoutSummary');

  function updateCartUI(){
    const items = Object.values(cart);
    let total = 0;
    cartItemsEl.innerHTML = '';
    if(items.length === 0){
      cartItemsEl.innerHTML = '<p class="muted">Your cart is empty. Add some books!</p>';
    } else {
      items.forEach(it => {
        total += it.qty * it.price;
        const el = document.createElement('div');
        el.className = 'cart-item';
        el.innerHTML = `<div style="display:flex;gap:8px;align-items:center">
                          <div style="width:44px;height:66px;background:#f0fbff;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:11px;color:#014f86">${it.title.split(' ')[0]}</div>
                          <div><strong>${it.title}</strong><div class="muted" style="font-size:12px">qty: ${it.qty}</div></div>
                        </div>
                        <div style="margin-left:auto"><strong>$${(it.qty*it.price).toFixed(2)}</strong><div style="display:flex;gap:8px;margin-top:6px"><button class="btn ghost" data-action="decrease" data-id="${it.id}">-</button><button class="btn small" data-action="increase" data-id="${it.id}">+</button></div></div>`;
        cartItemsEl.appendChild(el);
      });
    }
    cartCountEl.textContent = items.reduce((s,i)=>s+i.qty,0);
    cartTotalEl.textContent = '$' + total.toFixed(2);
  }

  // add to cart handlers
  document.querySelectorAll('.add-to-cart').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const id = btn.dataset.id;
      const title = btn.dataset.title;
      const price = parseFloat(btn.dataset.price);
      if(!cart[id]) cart[id] = {id, title, price, qty:0};
      cart[id].qty++;
      updateCartUI();
      // small animation
      btn.animate([{transform:'scale(1)'},{transform:'scale(1.06)'},{transform:'scale(1)'}],{duration:220});
    });
  });

  // open/close cart
  openCartBtn.addEventListener('click', () => {
    cartSidebar.classList.add('open');
    cartSidebar.setAttribute('aria-hidden','false');
    updateCartUI();
  });
  closeCartBtn.addEventListener('click', () => {
    cartSidebar.classList.remove('open');
    cartSidebar.setAttribute('aria-hidden','true');
  });

  // delegate increase/decrease in cart
  cartItemsEl.addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if(!btn) return;
    const action = btn.dataset.action;
    const id = btn.dataset.id;
    if(action === 'increase') cart[id].qty++;
    if(action === 'decrease'){ cart[id].qty--; if(cart[id].qty<=0) delete cart[id]; }
    updateCartUI();
  });

  clearCartBtn.addEventListener('click', () => {
    for(const k in cart) delete cart[k];
    updateCartUI();
  });

  // checkout flow
  checkoutBtn.addEventListener('click', () => {
    checkoutModal.classList.add('open');
    checkoutModal.setAttribute('aria-hidden','false');
    // fill summary
    const items = Object.values(cart);
    if(items.length === 0){
      checkoutSummary.innerHTML = '<p class="muted">Your cart is empty.</p>';
    } else {
      let html = '<ul style="padding-left:16px">';
      let total = 0;
      items.forEach(it => { total += it.price*it.qty; html += `<li>${it.title} — ${it.qty} × $${it.price.toFixed(2)}</li>`; });
      html += `</ul><p style="font-weight:700">Total: $${total.toFixed(2)}</p>`;
      checkoutSummary.innerHTML = html;
    }
  });

  closeCheckout.addEventListener('click', () => {
    checkoutModal.classList.remove('open');
    checkoutModal.setAttribute('aria-hidden','true');
  });

  checkoutForm.addEventListener('submit', (e) => {
    e.preventDefault();
    // simulate payment success
    alert('Thank you! Your order has been placed.');
    // clear cart
    for(const k in cart) delete cart[k];
    updateCartUI();
    checkoutModal.classList.remove('open');
    checkoutModal.setAttribute('aria-hidden','true');
    cartSidebar.classList.remove('open');
  });

  // slider functionality
  const track = document.getElementById('sliderTrack');
  const slides = Array.from(track.children);
  let index = 0;
  const prev = document.getElementById('prevSlide');
  const next = document.getElementById('nextSlide');

  function goTo(i){
    index = (i + slides.length) % slides.length;
    const x = index * (slides[0].getBoundingClientRect().width + 16);
    track.style.transform = `translateX(-${x}px)`;
  }
  prev.addEventListener('click', () => goTo(index-1));
  next.addEventListener('click', () => goTo(index+1));
  // autoplay
  setInterval(()=> goTo(index+1), 4500);

  // keyboard accessibility
  document.addEventListener('keydown', (e) => {
    if(e.key === 'Escape'){
      cartSidebar.classList.remove('open');
      checkoutModal.classList.remove('open');
    }
  });

});
